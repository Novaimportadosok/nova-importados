NOVA IMPORTADOS - IMAGENES DEL CATALOGO

Este paquete contiene:
- images/: 71 fotos extraídas del PDF del catálogo
- app.js: tu app.js con las rutas de imagen actualizadas a images/...

Para GitHub:
1. Subí la carpeta images completa al repositorio, en la misma ubicación que index.html y app.js.
2. Reemplazá el app.js actual por el app.js incluido en este paquete.
3. Hacé Commit changes.
4. Esperá unos minutos y recargá la página.

No borres index.html ni style.css.
